# 새 대화 시 맥락 요약 (지휘 지시문)

**용도**: Chat/Composer를 새로 열 때 이 문서를 **@docs/Context_Summary_For_New_Chat.md** 로 첨부하거나, 아래 요약을 붙여넣으면 AI가 Aegis-X v3의 현재 단계와 결론을 즉시 반영할 수 있습니다.

---

## 프로젝트 정체

- **Aegis-X v3**: SE 문서(docx_md, 00~65) 기반 자산운용 시스템. 엄격한 DB-First, 모듈 경계, Single Write Path.

## 확정 전제 (변경 금지)

- **컨테이너**: `aegisx-db` / **DB**: `aegisx` / **유저**: postgres / **호스트 포트**: 5433  
- **.env**: `DATABASE_URL=postgresql+psycopg2://postgres:2041@localhost:5433/aegisx`  
- **마이그레이션**: PowerShell에서 `< file.sql` 사용 금지 → `Get-Content -Raw | docker exec -i ... psql` 파이프 방식.

## Chain of Command (절대 위반 금지)

1. **DB-Only Read**: UI·상위 계층은 `engine_snapshot`만 조회, 직접 계산 금지.  
2. **Strict Module Boundary**: `engines/`는 순수 함수(dict in, dict out), DB/SQL 금지.  
3. **Single Write Path**: 엔진 결과는 `core/snapshot_repo.py`를 통해서만 DB 기록.

## Snapshot 6종 키 (Phase 0-1 정본)

- `engine_heartbeat`, `comm_health`, `regime_current`, `operation_mode`, `llm_status`, `risk_guard`  
- 스크립트: 동기 `run_single_cycle_sync` + `SessionLocal`. API: 비동기 `get_db` + `AsyncSessionLocal` (Phase 0-2).

## 현재 단계 요약 (새 단계 시작 시 여기만 갱신)

- **외부 기관 통신**: 모든 API Key는 **Windows 11 환경변수**에 설정. `backend/app/core/env_keys.py`에서만 조회. 통신 확인: `python scripts/check_comm.py` (FRED, LLM, KIS). → docs/ENV_Windows11_API_Keys.md
- DB 마이그레이션은 **migrate_db.ps1**(파이프 방식), 컨테이너 **aegisx-db** 기준으로 적용 완료.  
- Worker는 **run_engine_worker.ps1** → **run_engine_cycle.py**(동기)로 6종 스냅샷 적재.  
- 다음: [ ] check_comm.py 통신 확립 → [ ] API /api/health, /api/snapshot/{key} 정상 응답 확인 → [ ] Warroom Home 6종 렌더링.

## 참조 문서 (@ 로 첨부 권장)

- **@docs/Cursor_Developer_Mode_Hard_Lock.md** — Hard Architecture Lock 전조문 (필수)
- **@docs/Cursor_SOP_Standard_Operating_Order.md** — 1페이지 SOP (작업 시작 전 항상 읽고 따르기)
- **@docs/LLM_Staffing_Fallback_Plan.md** — LLM N+1 Fallback, LKS, Warroom 표시 규격
- **@docs/64_Phase0_1_DB_and_MinWorker_Package_Spec.md**  
- **@docs/65_Final_Directory_Architecture_Lock_Spec.md**  
- **@docs/Cursor_Final_Development_Strategy.md**  
- **@docs/Phase0_1_Run_Checklist.md**

## 계약 테스트 (설계 위반 시 빌드 실패)

- `test_one_cycle_produces_six_snapshot_keys` — 엔진 1사이클 후 6종 키·refresh_rate_sec·generated_at 존재
- `test_ui_never_calls_compute` — UI/API에서 engines import 금지 (DB-Only Read)
- `test_single_write_path_only` — DB 쓰기는 repo 모듈만 허용
