# Aegis-x v3 SE Master Index

This directory contains the full Software Engineering Documentation Set.

**Design Status**: Frozen (v3.0)

**참조 기준(Reference)**: `D:\AEGIS-X_v3\docx_md` — docs의 SE 문서는 docx_md 내 문서를 참조하여 Realign된 버전입니다.

All implementation must strictly follow these documents.

---

## 참조 소스 및 Realign

- **참조 경로**: `D:\AEGIS-X_v3\docx_md`
- **적용 방법**: docx_md 내 모든 문서를 docs/ 로 복사하여 동기화. docs/ 의 00_~65_ 계열 및 관련 문서는 docx_md와 일치합니다.
- **실라인 체크리스트**: [System_Realignment_Checklist.md](./System_Realignment_Checklist.md) — DB·엔진·게이트·실행·API가 docx_md/64·65·43 등 명세와 일치하는지 점검.

---

## docx_md 기준 문서 구성 (00 ~ 65)

| 번호 | 문서 | 비고 |
|------|------|------|
| 00~04 | 00_System_Charter, 01_Stakeholder_Requirements_SRS, 02_System_Architecture_SAD, 03_External_Interface_Control_Document_ICD, 04_Data_Architecture_DDD | 헌장, SRS, SAD, ICD, DDD |
| 05~12 | 05_Regime_Engine_Spec, 06_Allocation_Risk_Learning_Spec, 07_Fleet_Execution_Spec, 08_Digital_Twin_Spec, 09_Meta_Control_Spec, 10_Self_Healing_Spec, 11_Governance_Audit_Spec, 12_Capital_Scaling_Spec | 엔진·실행·Twin·메타·자기치유·거버넌스·스케일링 |
| 14~18 | 14_Test_Verification_Validation_Plan_TVP, 15_Risk_Register, 16_Config_Management_Plan, 17_Security_Model, 18_CIC_Warroom_Spec | TVP, 리스크, 형상, 보안, CIC Warroom |
| 29~43 | 29_Battlefield_Definition, 30_Global_Force_Follow_The_Sun, 31_Force_Organization, 32_Warroom_IA, 33_Ubiquitous_Command, 34~39 Force/Regime, 40_AAR_Learning, 41_Execution_Deployment, 42_Roadmap_90D, 43_DB_Schema_v1_Core_Spec.sql, 43_1_MVP_Infrastructure | 전장·부대·Warroom·실행·로드맵·DB 스키마 |
| 47~65 | 47/48_Engine_Worker_Skeleton, 49_Mode_Execution_Layer, 50_Pre_Trade_Gate, 51_Order_Execution, 52_Portfolio_State, 53~62 AAR/Pilot/Test, 63_Day1_Pilot_Runbook, 64_Phase0_1_DB_and_MinWorker, 65_Final_Directory_Architecture_Lock | 워커·게이트·실행·파일럿·Phase0·구조 락 |

---

## 기존 SE_01~SE_64와의 관계

- **SE_01 ~ SE_64**: 기존 모듈/전략별 스펙 (시스템 비전, 부대 구조, 레짐, 자본 배분, Strike/Swing/Core/Reserve 등). docx_md의 00_~65_ 번호 체계와 내용상 대응되며, **권장 참조는 docx_md** 입니다.
- **65_Final_Directory_Architecture_Lock_Spec.md**: 디렉터리/아키텍처 동결 — `/backend/app/` 구조 변경 금지, DB-First, Gate/Mode/Risk 체계.

---

## Change Management

- Any modification requires version bump.
- Regression impact must be analyzed.
- Audit record mandatory.
- docx_md 수정 시 docs/ 에 동기화 후 실라인 체크리스트 실행 권장.
