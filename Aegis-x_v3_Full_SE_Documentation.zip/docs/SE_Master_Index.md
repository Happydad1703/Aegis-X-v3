# Aegis-x v3 SE Master Index

This directory contains the full Software Engineering Documentation Set (SE-01~SE-64).

Design Status: Frozen (v3.0)

All implementation must strictly follow these documents.

Change Management:
- Any modification requires version bump.
- Regression impact must be analyzed.
- Audit record mandatory.
