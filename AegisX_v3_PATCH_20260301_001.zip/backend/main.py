from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session

# NOTE: imports rely on backend being a package (backend/__init__.py)
from backend.app.core.db import get_db
from backend.app.core.snapshot_repo import get_latest_snapshot

app = FastAPI(title="Aegis-x v3")

@app.get("/healthz")
def healthz():
    return {"status": "ok"}

@app.get("/api/health")
def api_health(db: Session = Depends(get_db)):
    return {
        "engine_heartbeat": get_latest_snapshot(db, "engine_heartbeat"),
        "health_status": get_latest_snapshot(db, "health_status"),
    }
