\
    Write-Host "Running one engine cycle..."
    Write-Host "PWD: $((Get-Location).Path)"
    python -c "import sys; print('PYTHONPATH[0]=', sys.path[0]); from backend.app.core.db import SessionLocal; from backend.app.workers.engine_worker import run_single_cycle; db=SessionLocal(); run_single_cycle(db); db.close(); print('OK: engine cycle done')"
