\
    Write-Host "GET http://localhost:8000/api/health"
    (Invoke-WebRequest http://localhost:8000/api/health).Content
